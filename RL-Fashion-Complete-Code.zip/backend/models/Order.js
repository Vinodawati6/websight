const mongoose = require("mongoose");

const OrderSchema = new mongoose.Schema({
  userId: String,
  products: Array,
  totalPrice: Number,
  paymentMethod: String
});

module.exports = mongoose.model("Order", OrderSchema);