const container = document.getElementById("products");

fetch("http://localhost:5000/api/products")
.then(res=>res.json())
.then(data=>{

data.forEach(product=>{

const card = document.createElement("div");
card.className="card";

card.innerHTML=`
<img src="${product.image}" />
<h3>${product.name}</h3>
<p>$${product.price}</p>
<button onclick="addCart('${product._id}')">Add to Cart</button>
`;

container.appendChild(card);

});

});

function addCart(id){

let cart = JSON.parse(localStorage.getItem("cart")) || [];
cart.push(id);
localStorage.setItem("cart",JSON.stringify(cart));

alert("Added to cart");

}